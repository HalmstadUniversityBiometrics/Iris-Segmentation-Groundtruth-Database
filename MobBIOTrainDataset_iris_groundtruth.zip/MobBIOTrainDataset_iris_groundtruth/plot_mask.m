

%Iris Segmentation Groundtruth (IRISSEG-CC Dataset)
%http://islab.hh.se/mediawiki/Iris_Segmentation_Groundtruth

%Copyright 2014: Fernando Alonso-Fernandez, Josef Bigun
%Halmstad University, Sweden
%Contact: Fernando Alonso-Fernandez (feralo@hh.se)

%Please check the link above for instructions on how to reference this
%segmentation dataset on any work made public based directly or indirectly
%on it

%Run this file to obtain the segmentation masks
%Filenames follow the same convention than the original database

%Iris circles
%Eyelids circles
path_in='.\manual_segmentation\'

%Output folder to store the masks
path_out='.\output\';

usuarios=dir([path_in '*_iris_circles.mat']);

%Size of Mobbio images
I=200;
J=250;

[X,Y]=meshgrid(1:J,1:I);


for i=1:length(usuarios)
    
    i
    
    image=usuarios(i).name;
    
    user=image(1:3);
    
    image_name=image(1:end-17);
    
    load([path_in image_name '_iris_circles.mat'])%,'pupil_circle','sclera_circle')
    
    load([path_in image_name '_eyelids_circles.mat']) %,'upper_eyelid','lower_eyelid')
    
    mask=zeros(I,J);
    
    mask1=((X-pupil_circle(1)).^2+(Y-pupil_circle(2)).^2)>=(pupil_circle(3)^2);
    
    mask2=((X-sclera_circle(1)).^2+(Y-sclera_circle(2)).^2)<=(sclera_circle(3)^2);
    
    mask3=((X-upper_eyelid(1)).^2+(Y-upper_eyelid(2)).^2)<=(upper_eyelid(3)^2);
    
    mask4=((X-lower_eyelid(1)).^2+(Y-lower_eyelid(2)).^2)<=(lower_eyelid(3)^2);
    
    segmentation_mask=mask1.*mask2.*mask3.*mask4;
    
    %Save image
    imwrite(segmentation_mask,[path_out image_name '.png']);
    
    %As .mat
    save([path_out image_name '.mat'],'segmentation_mask');
    
end


close all

